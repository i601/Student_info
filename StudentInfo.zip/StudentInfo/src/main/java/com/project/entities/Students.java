package com.project.entities;

public class Students {
	
	private long id;
	private String name;
	private String branch;
	private double marks;
	
	public Students() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Students(long id, String name, String branch, double marks) {
		super();
		this.id = id;
		this.name = name;
		this.branch = branch;
		this.marks = marks;
	}

	public long getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getMarks() {
		return marks;
	}

	public void setMarks(double marks) {
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "Students [id=" + id + ", name=" + name + ", branch=" + branch + ", marks=" + marks + "]";
	}
	
	

}
