package com.project.services;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.project.entities.Students;

@Service
public class StudentServiceImpl implements StudentService{
	
	List<Students> list;

	public StudentServiceImpl() {
		list = new ArrayList<>();
		list.add(new Students( 101,"King","Extc",80.21));
		list.add(new Students( 102,"Queen","Extc",70.21));
	}

	@Override
	public List<Students> getStudents() {
		
		return list;
	}

	@Override
	public Students getStudent(long studentId) {
		
		Students s= null;
		for(Students students:list)
		{
			if(students.getId()==studentId)
			{
				s = students;
				break;
			}
		}
		return s;
		
		
	}

	@Override
	public Students addStudent(Students student) {
		list.add(student);
		return student;
	}
	

}
