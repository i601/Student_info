package com.project.services;

import java.util.List;

import com.project.entities.Students;

public interface StudentService {
	public List<Students> getStudents();
	
	public Students getStudent(long studentId);
	
	public Students addStudent(Students student);

}
