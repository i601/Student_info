package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.entities.Students;
import com.project.services.StudentService;

@RestController//for json so we use rest
public class MyController
{
	@Autowired
	private StudentService studentsService;
	
	@GetMapping("/home")
   public String Home()
   {
	   return "Welcome in Open House";
	   
   }
   @GetMapping("/students")
	public List<Students> getStudents()
	{
		return this.studentsService.getStudents();
	}
   @GetMapping("/students/{studentId}")
  	public Students getStudent(@PathVariable String studentId)
  	{
  		return  this.studentsService.getStudent(Long.parseLong(studentId));
  	}
   @PostMapping("/students")
   public Students addStudent(@RequestBody Students student)
 	{
 		return this.studentsService.addStudent(student);
 	}
}
